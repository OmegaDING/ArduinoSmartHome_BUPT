Description of these documents:
1. Backend System Source Code(Eclipse Project).zip ---- This is the souce code of our backend DBMS, you can uncompress and open it in Eclipse.
2. ER Model.mwb ---- The ER model of our database, exported from MySQL Workbench.
3. ER Model.png ---- The ER model diagram.
4. Create Database SQL Statements.sql ---- You can excute these SQL statements in MySQL to generate the database with test data imported.
5. Test Data ---- This folder contains all the test data we made for our database.

Further details of our job are covered in our final report.