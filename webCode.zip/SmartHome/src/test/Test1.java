package test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Test1 {

	
	public static void main(String[] args) {
		Date date = new Date();//��ȡ��ǰʱ��
	    String strDateFormat = "yyyy-MM-dd HH:mm:ss";
	    SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
	    System.out.println(date); 
	}
	
}
