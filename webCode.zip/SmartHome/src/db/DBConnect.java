package db;


import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	private final String DBDRIVER = "com.mysql.jdbc.Driver";
	private final String DBURL = "jdbc:mysql://192.168.23.62:3306/smarthome?useUnicode=true&characterEncoding=utf-8";
	private final String DBUSER = "ecom";
	private final String DBPASSWORD = "123456";
	private Connection conn = null;

	public DBConnect() {
		try {
			Class.forName(DBDRIVER);
			this.conn = DriverManager.getConnection(DBURL, DBUSER, DBPASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		};
	}

	public Connection getConnection() {
		return this.conn;
	}

	public void close() {
		try {
			this.conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}