package vo;

public class Family {
	private String  fID;
    private String fName;
    private String address;
    private int status;
    public Family() {
    	
    }
    public Family(String fID, String fName, String address, int status) {
		super();
		this.fID = fID;
		this.fName = fName;
		this.address = address;
		this.status = status;
	}
	public String getfID() {
		return fID;
	}
	public void setfID(String fID) {
		this.fID = fID;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	

}
