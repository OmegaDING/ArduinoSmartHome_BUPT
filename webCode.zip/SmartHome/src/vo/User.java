package vo;

public class User {
        private String userID;
        private String userPassword;
        private String userName;
        private String userPhone;
        private String userGender;
        private int status;
		
        public User() {}
		public User(String userID, String userPassword, String userName, String userPhone, String userGender,
				int status) {
			super();
			this.userID = userID;
			this.userPassword = userPassword;
			this.userName = userName;
			this.userPhone = userPhone;
			this.userGender = userGender;
			this.status = status;
		}
		public String getUserID() {
			return userID;
		}
		public void setUserID(String userID) {
			this.userID = userID;
		}
		public String getUserPassword() {
			return userPassword;
		}
		public void setUserPassword(String userPassword) {
			this.userPassword = userPassword;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getUserPhone() {
			return userPhone;
		}
		public void setUserPhone(String userPhone) {
			this.userPhone = userPhone;
		}
		public String getUserGender() {
			return userGender;
		}
		public void setUserGender(String userGender) {
			this.userGender = userGender;
		}
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		
        
}
