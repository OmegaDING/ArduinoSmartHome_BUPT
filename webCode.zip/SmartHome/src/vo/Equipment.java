package vo;

public class Equipment {
	

	private String eID;
	private String eName;
	private String description;
	private int status;
	private String cID;
	private String mID;
	private String fID;
	
	public String geteID() {
		return eID;
	}
	public void seteID(String eID) {
		this.eID = eID;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getcID() {
		return cID;
	}
	public void setcID(String cID) {
		this.cID = cID;
	}
	public String getmID() {
		return mID;
	}
	public void setmID(String mID) {
		this.mID = mID;
	}
	public String getfID() {
		return fID;
	}
	public void setfID(String fID) {
		this.fID = fID;
	}
	public Equipment(String eID, String eName, String description, int status, String cID, String mID, String fID) {
		super();
		this.eID = eID;
		this.eName = eName;
		this.description = description;
		this.status = status;
		this.cID = cID;
		this.mID = mID;
		this.fID = fID;
	}
	public Equipment() {
	}
}