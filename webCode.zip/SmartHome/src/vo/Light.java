package vo;

import java.util.Date;

public class Light {
	 private String lightID;
     private int lightState;
    // java.util.Date lightUpdateTime = new java.util.Date();
     private String lightUpdateTime;
     public Light() {}
	public Light(String lightID, int lightState, String lightUpdateTime) {
		super();
		this.lightID = lightID;
		this.lightState = lightState;
		this.lightUpdateTime = lightUpdateTime;
	}
	public String getLightID() {
		return lightID;
	}
	public void setLightID(String lightID) {
		this.lightID = lightID;
	}
	public int getLightState() {
		return lightState;
	}
	public void setLightState(int lightState) {
		this.lightState = lightState;
	}
	public String getLightUpdateTime() {
		return lightUpdateTime;
	}
	public void setLightUpdateTime(String lightUpdateTime) {
		this.lightUpdateTime = lightUpdateTime;
	};
	
   
}
