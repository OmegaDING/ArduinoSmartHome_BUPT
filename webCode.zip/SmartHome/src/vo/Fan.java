package vo;

public class Fan {
	private String fanID;
	private int fanState;
	private String fanUpdateTime;
	
	 
//	public Fan(String fanID, int fanState, String fanUpdateTime) {
//		super();
//		this.fanID = fanID;
//		this.fanState = fanState;
//		this.fanUpdateTime = fanUpdateTime;
//	}
	public String getFanID() {
		return fanID;
	}
	public void setFanID(String fanID) {
		this.fanID = fanID;
	}
	public int getFanState() {
		return fanState;
	}
	public void setFanState(int fanState) {
		this.fanState = fanState;
	}
	public String getFanUpdateTime() {
		return fanUpdateTime;
	}
	public void setFanUpdateTime(String fanUpdateTime) {
		this.fanUpdateTime = fanUpdateTime;
	}
}
