package vo;

public class Hygrometer {
	 
	private Float humValue;
	private String humUpdateTime;
	
	 
 
	public Float getHumValue() {
		return humValue;
	}
	public void setHumValue(Float humValue) {
		this.humValue = humValue;
	}
	public String getHumUpdateTime() {
		return humUpdateTime;
	}
	public void setHumUpdateTime(String humUpdateTime) {
		this.humUpdateTime = humUpdateTime;
	}
	
	
}
