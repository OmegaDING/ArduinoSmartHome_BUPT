package vo;

public class Gas {
	private String gasID;
	private int gasState;
	private String gasUpdateTime;
	
	
	public String getGasID() {
		return gasID;
	}
	public void setGasID(String gasID) {
		this.gasID = gasID;
	}
	public int getGasState() {
		return gasState;
	}
	public void setGasState(int gasState) {
		this.gasState = gasState;
	}
	public String getGasUpdateTime() {
		return gasUpdateTime;
	}
	public void setGasUpdateTime(String gasUpdateTime) {
		this.gasUpdateTime = gasUpdateTime;
	}
}
