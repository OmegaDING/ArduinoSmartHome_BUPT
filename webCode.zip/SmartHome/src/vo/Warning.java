package vo;

public class Warning {
	private String warnID;
	private int warnState;
	private String warnUpdateTime;
	
	
	public String getWarnID() {
		return warnID;
	}
	public void setWarnID(String warnID) {
		this.warnID = warnID;
	}
	public int getWarnState() {
		return warnState;
	}
	public void setWarnState(int warnState) {
		this.warnState = warnState;
	}
	public String getWarnUpdateTime() {
		return warnUpdateTime;
	}
	public void setWarnUpdateTime(String warnUpdateTime) {
		this.warnUpdateTime = warnUpdateTime;
	}
}
