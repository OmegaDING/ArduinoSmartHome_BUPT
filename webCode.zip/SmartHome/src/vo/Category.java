package vo;

public class Category {

	private String cgID;
	private String cgName;
	public String getCgID() {
		return cgID;
	}
	public void setCgID(String cgID) {
		this.cgID = cgID;
	}
	public String getCgName() {
		return cgName;
	}
	public void setCgName(String cgName) {
		this.cgName = cgName;
	}

	
}
