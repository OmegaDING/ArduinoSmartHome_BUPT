package vo;

public class ManufacturerBean {
	private String mfID;
	private String mfName;
	public String getMfID() {
		return mfID;
	}
	public void setMfID(String mfID) {
		this.mfID = mfID;
	}
	public String getMfName() {
		return mfName;
	}
	public void setMfName(String mfName) {
		this.mfName = mfName;
	}
	
	
 
	
 
}
