package vo;

public class DoorsAndWindows {
	private String dwID;
	private String dwName;
	private int dwState;
	private String dwUpdateTime;
	
	
	
	public String getDwName() {
		return dwName;
	}
	public void setDwName(String dwName) {
		this.dwName = dwName;
	}
	public String getDwID() {
		return dwID;
	}
	public void setDwID(String dwID) {
		this.dwID = dwID;
	}
	public int getDwState() {
		return dwState;
	}
	public void setDwState(int dwState) {
		this.dwState = dwState;
	}
	public String getDwUpdateTime() {
		return dwUpdateTime;
	}
	public void setDwUpdateTime(String dwUpdateTime) {
		this.dwUpdateTime = dwUpdateTime;
	}
	
	
}
