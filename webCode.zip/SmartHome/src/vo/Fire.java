package vo;

public class Fire {
	private String fireID;
	private int fireState;
	private String fireUpdateTime;
	
	
	public String getFireID() {
		return fireID;
	}
	public void setFireID(String fireID) {
		this.fireID = fireID;
	}
	public int getFireState() {
		return fireState;
	}
	public void setFireState(int fireState) {
		this.fireState = fireState;
	}
	public String getFireUpdateTime() {
		return fireUpdateTime;
	}
	public void setFireUpdateTime(String fireUpdateTime) {
		this.fireUpdateTime = fireUpdateTime;
	}
}
