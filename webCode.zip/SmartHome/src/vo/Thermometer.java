package vo;

public class Thermometer {

	private Float temValue;
	private String temUpdateTime;
	
	public Float getTemValue() {
		return temValue;
	}
	public void setTemValue(Float temValue) {
		this.temValue = temValue;
	}
	public String getTemUpdateTime() {
		return temUpdateTime;
	}
	public void setTemUpdateTime(String temUpdateTime) {
		this.temUpdateTime = temUpdateTime;
	}
	
	
}
