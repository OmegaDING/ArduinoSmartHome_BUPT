package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import myservlet.dao.GasDao;
import myservlet.dao.impl.GasDaoimpl;
import vo.Gas;

@WebServlet("/GasServlet")
public class GasServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		String gasUpdateTime=req.getParameter("gasUpdateTime");//������ʱ����Ϣ
		
		GasDao gasDao=new GasDaoimpl();
		List<Gas> gas=gasDao.getGas();//���ݿ��ѯ
		 //Ԥ��servlet��Ϊ�Ժ�ʹ��js��׼��
		 String str = JSON.toJSONString(gas); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
