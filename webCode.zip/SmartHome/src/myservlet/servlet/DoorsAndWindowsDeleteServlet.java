package myservlet.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import myservlet.dao.impl.DoorsAndWindowsDeleteDAO;
import vo.DoorsAndWindows;
import vo.Equipment;




/**
 * Servlet implementation class LightServlet
 */

public class DoorsAndWindowsDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    DoorsAndWindows dw=new DoorsAndWindows();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			    E.seteID(eID);
			    dw.setDwID(eID);
			   // light.setLightUpdateTime(lightUpdateTime);
			
				
				DoorsAndWindowsDeleteDAO dao=new DoorsAndWindowsDeleteDAO();
				
				dao.getdw(dw,E);
				
				
				request.setAttribute("dw", dw);
				response.sendRedirect("./usertext.html");

	}
	

}
