package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myservlet.dao.LightDao;
import myservlet.dao.impl.LightAddDAO;
import myservlet.dao.impl.LightDAOImpl;
import vo.Equipment;
import vo.Light;



/**
 * Servlet implementation class LightServlet
 */
@WebServlet("/LightAddServlet")
public class LightAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    Light light = new Light();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			//    int lightState=Integer.parseInt(request.getParameter("State"));
			//    String lightUpdateTime=request.getParameter("UpdateTime");
			    
			    String eName=request.getParameter("eName");
			    String description=request.getParameter("description");
			  //  int status=Integer.parseInt(request.getParameter("status"));
			    String cID=request.getParameter("cID");
			    String mID=request.getParameter("mID");
//			    String fID=request.getParameter("fID");

			    E.seteID(eID);
			    E.setcID(cID);
			    E.setmID(mID);
			    E.seteName(eName);
			    E.setDescription(description);
			    E.setStatus(0);
			    
			    
			    light.setLightState(0);
			    light.setLightID(eID);
			 //   light.setLightUpdateTime(lightUpdateTime);
			//	String lightUpdateTime=request.getParameter("lightUpdateTime");//闋侀潰缁欑殑鏃堕棿淇℃伅
				
				LightAddDAO dao=new LightAddDAO();
				
				dao.getLight(light,E);//鏁版嵁搴撴煡璇�
				//ArrayList<Equipment> equipment=dao.getEquipment(eID,eName,description,status,cID,mID,fID);
				
				request.setAttribute("light", light);
				response.sendRedirect("./smart-home-finally.html");
//				request.getRequestDispatcher("./light.jsp").forward(request, response);
	}
	

}
