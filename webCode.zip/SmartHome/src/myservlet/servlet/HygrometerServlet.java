package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.JSON;
import myservlet.dao.HygrometerDao;
import myservlet.dao.ThermometerDao;
import myservlet.dao.impl.HygrometerDaoimpl;
import vo.Hygrometer;
import vo.Thermometer;

public class HygrometerServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		//String humTime=req.getParameter("humTime");//������ʱ����Ϣ
	
		HygrometerDao hygrometerDao=new HygrometerDaoimpl();
		List<Hygrometer> hygrometers=hygrometerDao.getHygrometers();//���ݿ��ѯ
		
		
		String str = JSON.toJSONString(hygrometers); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();  
	     out.close();  
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
