package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.JSON;
import myservlet.dao.ManufacturerSelectDao;
import myservlet.dao.impl.ManufacturerSelectDaoImpl;
import vo.ManufacturerBean;
 


@WebServlet("/ManufacturerServlet")
public class ManufacturerServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		
		ManufacturerSelectDao mDao=new ManufacturerSelectDaoImpl();
		List<ManufacturerBean> mList=mDao.getManufacturers();
  
		 String str = JSON.toJSONString( mList) ;
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
