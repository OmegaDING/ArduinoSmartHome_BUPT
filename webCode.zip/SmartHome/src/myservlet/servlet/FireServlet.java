package myservlet.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import myservlet.dao.FireDao;
import myservlet.dao.impl.FireDaoimpl;
import vo.Fire;


@WebServlet("/FireServlet")
public class FireServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
//		String fireUpdateTime=req.getParameter("fireUpdateTime");//������ʱ����Ϣ
		
		
	
		
		
		FireDao fireDao=new FireDaoimpl();
		List<Fire> fire=fireDao.getFire();//���ݿ��ѯ
		 //Ԥ��servlet��Ϊ�Ժ�ʹ��js��׼��
		 String str = JSON.toJSONString(fire); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
