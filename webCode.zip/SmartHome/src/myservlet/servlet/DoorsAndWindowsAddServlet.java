package myservlet.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import myservlet.dao.impl.DoorsAndWindowsAddDAO;
import vo.DoorsAndWindows;
import vo.Equipment;




/**
 * Servlet implementation class LightServlet
 */

public class DoorsAndWindowsAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    DoorsAndWindows dw = new DoorsAndWindows();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			    
			  
			    
			    String eName=request.getParameter("eName");
			    String description=request.getParameter("description");
			  
			    String cID=request.getParameter("cID");
			    String mID=request.getParameter("mID");
			   

			    E.seteID(eID);
			    E.setcID(cID);
			    E.setmID(mID);
			    E.seteName(eName);
			    E.setDescription(description);
			    E.setStatus(0);
			    
			    
			    dw.setDwState(0);
			    dw.setDwID(eID);
			 //   dw.setDwUpdateTime(dwUpdateTime);
			//	String lightUpdateTime=request.getParameter("lightUpdateTime");//闋侀潰缁欑殑鏃堕棿淇℃伅
				
				DoorsAndWindowsAddDAO dao=new DoorsAndWindowsAddDAO();
				
				dao.getdw(dw,E);//鏁版嵁搴撴煡璇�
				//ArrayList<Equipment> equipment=dao.getEquipment(eID,eName,description,status,cID,mID,fID);
				
				request.setAttribute("dw", dw);
				response.sendRedirect("./usertext.html");
//				request.getRequestDispatcher("./light.jsp").forward(request, response);
	}
	

}
