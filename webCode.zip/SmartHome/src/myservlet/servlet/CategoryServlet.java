package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.JSON;

import myservlet.dao.CategorySelectDao;
import myservlet.dao.ManufacturerSelectDao;
import myservlet.dao.impl.CategorySelectDaoImpl;
import myservlet.dao.impl.ManufacturerSelectDaoImpl;
import vo.Category;
import vo.ManufacturerBean;
 


@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		String typeName=request.getParameter("typeName");
		CategorySelectDao cDao=new CategorySelectDaoImpl();
		Category category=cDao.getCategories(typeName);
		
	 
		 String str = JSON.toJSONString( category) ;
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
