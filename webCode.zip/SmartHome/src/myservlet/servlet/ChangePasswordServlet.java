package myservlet.servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.xml.internal.fastinfoset.util.ValueArrayResourceException;

import myservlet.dao.impl.UserDAOImpl;


import vo.Family;
import vo.User;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String familyid="";
	
	 public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		 User user = new User();
		 Family f =new Family();
		 user.setUserName(req.getParameter("username"));
		 String OldPassword=req.getParameter("password");
		 String NewPassword=req.getParameter("new_password");
		 HttpSession session = req.getSession();
	     String codeServer= session.getAttribute("code").toString();
		 if(OldPassword.equals(NewPassword)) {
			 user.setUserPassword(req.getParameter("new_password"));
			 String veryCode=req.getParameter("veryCode");
			 if(veryCode.equals(codeServer)) {
				 UserDAOImpl dao = new UserDAOImpl();   
			     int flag = 0;
			     try {
						flag = dao.changePassword(user);
				  } catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				  } 
			     if(flag == 1){   
						
//						HttpSession session=req.getSession();
//						session.setAttribute("user", user);
//						familyid=f.getfID();
			         res.sendRedirect("./login.html");
//			         res.sendRedirect("./smarthome.html");
			        } else { 
			        	System.out.println("the user doesn't exist");
			         res.sendRedirect("./user-not-exist.html");
			        }
			 }else {
				 res.sendRedirect("./user-not-exist.html");
			 }
			 
			
		 }
		 else {
			 System.out.println("error!");
			 
		 }
			 
		 
		
	 }
}
	 