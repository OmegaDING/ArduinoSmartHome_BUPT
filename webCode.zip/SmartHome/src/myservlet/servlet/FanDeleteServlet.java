package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myservlet.dao.LightDao;
import myservlet.dao.impl.FanDeleteDAO;
import myservlet.dao.impl.LightAddDAO;
import myservlet.dao.impl.LightDAOImpl;
import myservlet.dao.impl.LightDeleteDAO;
import vo.Equipment;
import vo.Fan;
import vo.Light;



/**
 * Servlet implementation class LightServlet
 */

public class FanDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    Fan fan = new Fan();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			    E.seteID(eID);
			    fan.setFanID(eID);
			
			
				
				FanDeleteDAO dao=new FanDeleteDAO();
				
				dao.getFan(fan,E);//鏁版嵁搴撴煡璇�
				
				
				request.setAttribute("fan", fan);
				response.sendRedirect("./usertext.html");

	}
	

}
