package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import myservlet.dao.ThermometerDao;
import myservlet.dao.impl.ThermometerDaoImpl;
import vo.Thermometer;

public class ThermometerServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
//		String temTime=req.getParameter("temTime");//������ʱ����Ϣ
//		temTime = temTime.replace('T',' ');
		ThermometerDao thermometerDao=new ThermometerDaoImpl();
		List<Thermometer> thermometers=thermometerDao.getThermometers();//���ݿ��ѯ
//		resp.sendRedirect("InitServlet?initTime=2021-05-06 09:06:23&dwTime=2021-05-06 09:06:23&lightTime=2021-05-06 09:06:23");
		req.setAttribute("thermometer", thermometers);
		 String str = JSON.toJSONString(thermometers); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
