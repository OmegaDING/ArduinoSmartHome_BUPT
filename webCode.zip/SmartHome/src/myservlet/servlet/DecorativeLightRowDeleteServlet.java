package myservlet.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import myservlet.dao.impl.DecorativelightRowSelectedDao;
import myservlet.dao.impl.LightDAOImpl;
import myservlet.dao.impl.LightRowSelectedDao;
import vo.User;
import vo.Light;


public class DecorativeLightRowDeleteServlet extends HttpServlet {
	
	 public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{

	 }
	
	 public void doGet(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		 Light light =new Light();
	
		 
		 DecorativelightRowSelectedDao dao= new DecorativelightRowSelectedDao(); 
	
		 
		 try {
			 ArrayList<Light> list=dao.query(2);
			System.out.println(list.get(0));
		
             req.setAttribute("list",list);
			
			req.getRequestDispatcher("./decorativelightdelete.jsp").forward(req, res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	  
		 
		
	 }
}