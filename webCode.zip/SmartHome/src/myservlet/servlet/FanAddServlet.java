package myservlet.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import myservlet.dao.impl.DoorsAndWindowsAddDAO;
import myservlet.dao.impl.FanAddDAO;
import vo.DoorsAndWindows;
import vo.Equipment;
import vo.Fan;




/**
 * Servlet implementation class LightServlet
 */

public class FanAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    Fan fan = new Fan();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			   
			    
			    String eName=request.getParameter("eName");
			    String description=request.getParameter("description");
			  
			    String cID=request.getParameter("cID");
			    String mID=request.getParameter("mID");
			  

			    E.seteID(eID);
			    E.setcID(cID);
			    E.setmID(mID);
			    E.seteName(eName);
			    E.setDescription(description);
			    E.setStatus(0);
			    
			    
			    fan.setFanState(0);
			    fan.setFanID(eID);
			 
		
				FanAddDAO dao=new FanAddDAO();
				
				dao.getfan(fan,E);//鏁版嵁搴撴煡璇�
			
				
				request.setAttribute("fan", fan);
				response.sendRedirect("./usertext.html");
//				request.getRequestDispatcher("./light.jsp").forward(request, response);
	}
	

}

