package myservlet.servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import myservlet.dao.UserDao;
import myservlet.dao.impl.UserDAOImpl;
import sun.awt.RepaintArea;
import sun.rmi.server.UnicastServerRef;
import vo.Family;
import vo.User;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static String familyid="";
	
	 public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		 User user = new User();
		 Family f =new Family();
		 user.setUserName(req.getParameter("username"));
		 user.setUserPassword(req.getParameter("password"));
		 String userId="0";
		 UserDAOImpl dao = new UserDAOImpl();   
	     int flag = 0;
	     try {
				userId = dao.queryByUsername(user,f);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		} 
		 if(!userId.equals("0")){   
			
			 HttpSession session=req.getSession();
			 session.setAttribute("user", user);
			 familyid=f.getfID();
			 Cookie namecookie  =   new  Cookie( "userName" ,user.getUserName());
			 Cookie idcookie  =   new  Cookie( "userID" ,String.valueOf(userId));  
			 res.addCookie(namecookie);
			 res.addCookie(idcookie);
	         res.sendRedirect("smart-home-finally.html");
//	         res.sendRedirect("./smarthome.html");
	        } else { 
	         res.sendRedirect("./error.html");
	        }
	 }
}
	 