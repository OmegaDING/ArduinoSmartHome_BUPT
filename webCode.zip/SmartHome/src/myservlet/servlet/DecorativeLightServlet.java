package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import myservlet.dao.LightDao;
import myservlet.dao.impl.DecorativeLightDAOImpl;
import myservlet.dao.impl.LightDAOImpl;
import vo.Light;



/**
 * Servlet implementation class LightServlet
 */
@WebServlet("/DecorativeLightServlet")
public class DecorativeLightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DecorativeLightServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    response.setHeader("Content-type", "text/html;charset=UTF-8");
			    String typeName=request.getParameter("typeName");
				String lightId=request.getParameter("lightId");//闋侀潰缁欑殑鏃堕棿淇℃伅
				
				LightDao dao=new DecorativeLightDAOImpl();
				ArrayList<Light> light=dao.getLight(typeName,lightId);//鏁版嵁搴撴煡璇�
				
				request.setAttribute("light", light);
				String str = JSON.toJSONString(light); 
				 PrintWriter out = response.getWriter();
				 out.print(str);
			     out.flush();  
			     out.close(); 
//				request.getRequestDispatcher("./light.jsp").forward(request, response);
	}
	

}
