package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.JSON;
import myservlet.dao.DoorsAndWindowsDao;
import myservlet.dao.DoorsAndWindowsDaoType;
import myservlet.dao.impl.DoorsAndWindowsDaoImplType;
import myservlet.dao.impl.DoorsAndWindowsDaoimpl;
import vo.DoorsAndWindows;
import vo.DoorsAndWindowsType;

@WebServlet("/DoorsAndWindowsTypeServlet")
public class DoorsAndWindowsTypeServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		String typeName=req.getParameter("typeName");
		
		DoorsAndWindowsDaoType doorsandwindowsDao=new DoorsAndWindowsDaoImplType();
		List<DoorsAndWindowsType> doorsandwindows=doorsandwindowsDao.doorsAndWindowsSelectTypes(typeName);//���ݿ��ѯ
		 //Ԥ��servlet��Ϊ�Ժ�ʹ��js��׼��
		 String str = JSON.toJSONString(doorsandwindows); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}
