package myservlet.servlet;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import myservlet.dao.impl.WindowsRowSelectedDao;
import vo.DoorsAndWindows;



public class WindowsRowDeleteServlet extends HttpServlet {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{

	 }
	
	 public void doGet(HttpServletRequest req, HttpServletResponse res)
	    throws IOException, ServletException{
		 DoorsAndWindows dw =new DoorsAndWindows();
	
		 
		 WindowsRowSelectedDao dao= new WindowsRowSelectedDao(); 
	
		 
		 try {
			 ArrayList<DoorsAndWindows> list=dao.query(2);
			System.out.println(list.get(0));
		
             req.setAttribute("list",list);
			
			req.getRequestDispatcher("./windowsdelete.jsp").forward(req, res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	  
		 
		
	 }
}