package myservlet.servlet;


import java.io.IOException;


 

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import myservlet.dao.UserDao;
import myservlet.dao.impl.UserDAOImpl;
import vo.Family;
import vo.User;

public class RegisterServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
 
    @Override
    protected void doPost(HttpServletRequest req,
    		HttpServletResponse res) throws ServletException, IOException {
    
    
         //获取注册用户信息 
    	String userID=req.getParameter("userid");   	
    	String userPassword=req.getParameter("password");
        String userName=req.getParameter("usersname");      
        String userPhone=req.getParameter("userphone");
        String userGender=req.getParameter("usergender");
        String familyID=req.getParameter("f_id");  
        String familyName=req.getParameter("f_name");
        String familyaddress=req.getParameter("f_address");
        int user_status=0;
        int f_status=0;
        
        //int x=0;
       // if(userID.length()<2)x=3;
       // if(userPassword.length()<5) x=2;
       // if(userPhone.length()!=8) x=1;
        
        UserDao dao = new UserDAOImpl();   
        int flag = 0; 
       /* if(x==0) {
        	try {
        		User user=new User(userID,userPassword,userName,userPhone,userGender,user_status);
        	    Family f =new Family(familyID,familyName,familyaddress,f_status);
    			flag = dao.Insert(user,f);
    		} catch (Exception e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    	    } 
        	 if(flag == 1){   
        	
        		
                 res.sendRedirect("./login.html");
                } else { 
                res.sendRedirect("./register.html");
               }        
        }
        else {
        	if(x==1) {
                req.setAttribute("message", "phone number must be of length 8");
                req.getRequestDispatcher("register.html").forward(req,res);
            }
            if(x==2) {
                 req.setAttribute("message", "Password length should be at least 5 digits");
                 req.getRequestDispatcher("register.html").forward(req,res);
            }
            if(x==3) {
                 req.setAttribute("message", "Password length should be at least 2 digits");
                 req.getRequestDispatcher("register.html").forward(req,res);
        }
        } */
        
       
        try { 
        	User user=new User(userID,userPassword,userName,userPhone,userGender,user_status);
	        Family f =new Family(familyID,familyName,familyaddress,f_status);
			flag = dao.Insert(user,f);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    } 
	   if(flag == 1){   		 
         res.sendRedirect("./login.html");
        } else { 
        res.sendRedirect("./register.html");
       }        
           
    }
        }
