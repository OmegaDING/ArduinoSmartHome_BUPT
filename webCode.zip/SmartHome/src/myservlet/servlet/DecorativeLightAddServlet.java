package myservlet.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myservlet.dao.DecorativeLightAddDAO;
import myservlet.dao.impl.DecorativeLightAddDaoImple;
import myservlet.dao.impl.LightAddDAO;
import vo.Equipment;
import vo.Light;



/**
 * Servlet implementation class LightServlet
 */

public class DecorativeLightAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
						
			    Light light = new Light();
			    Equipment E = new Equipment();
			    
			    String eID=request.getParameter("eID");
			    String eName=request.getParameter("eName");
			    String description=request.getParameter("description");
			    String cID=request.getParameter("cID");
			    String mID=request.getParameter("mID");
	

			    E.seteID(eID);
			    E.setcID(cID);
			    E.setmID(mID);
			    E.seteName(eName);
			    E.setDescription(description);
			    E.setStatus(0);
			    
			    
			    light.setLightState(100);
			    light.setLightID(eID);

				
				DecorativeLightAddDAO dao=new DecorativeLightAddDaoImple();
				
				dao.getLight(light,E);//鏁版嵁搴撴煡璇�
				//ArrayList<Equipment> equipment=dao.getEquipment(eID,eName,description,status,cID,mID,fID);
				
				request.setAttribute("light", light);
				response.sendRedirect("./usertext.html");
//				request.getRequestDispatcher("./light.jsp").forward(request, response);
	}
	

}
