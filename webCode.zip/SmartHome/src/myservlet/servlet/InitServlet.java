package myservlet.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import myservlet.dao.DoorsAndWindowsDao;
import myservlet.dao.EquipmentDao;
import myservlet.dao.HygrometerDao;
import myservlet.dao.LightDao;
import myservlet.dao.ThermometerDao;
import myservlet.dao.impl.DoorsAndWindowsDaoimpl;
import myservlet.dao.impl.EquipmentDaoImpl;
import myservlet.dao.impl.HygrometerDaoimpl;
import myservlet.dao.impl.LightDAOImpl;
import myservlet.dao.impl.ThermometerDaoImpl;
import vo.DoorsAndWindows;
import vo.Equipment;
import vo.Hygrometer;
import vo.Light;
import vo.Thermometer;

public class InitServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		//��ʼ����ʱ��
//		String initTime=req.getParameter("initTime");
//		if(initTime==null) {
//			initTime="2021-05-06 09:06:23";
//		}
//		//�Ŵ�ѡ���ʱ��(���ýӿڵ�ʱ���ֵ)
//		String dwTime=req.getParameter("dwTime");
//		if(dwTime==null) {
//			dwTime="2021-05-06 09:06:23";
//		}
//		//��ѡ���ʱ��(���ýӿڵ�ʱ���ֵ)
//		String lightTime=req.getParameter("lightTime");
//		if(lightTime==null) {
//			lightTime="2021-05-06 09:06:23";
//		}
//		//�¶�ѡ��ʱ��
//		String therTime=req.getParameter("therTime");
//		if(therTime!=null) {
//			therTime=therTime.replace("T", " ");
//		}
//		//ʪ��ѡ��ʱ��
//		String hygTime=req.getParameter("hygTime");
//		
//		
//		ThermometerDao thermometerDao=new ThermometerDaoImpl();
//		HygrometerDao hygrometerDao=new HygrometerDaoimpl();
//		DoorsAndWindowsDao doorsAndWindowsDao=new DoorsAndWindowsDaoimpl();
//		EquipmentDao equipmentDao=new EquipmentDaoImpl();
//		LightDao lightDao=new LightDAOImpl();
//		
//		List<Thermometer>  thermometerList=new ArrayList<>();
//		List<Hygrometer> hygrometersListnew=new  ArrayList<>();
//		List<DoorsAndWindows> doorsAndWindowsListnew=new  ArrayList<>();
//		List<Light> lightsListnew=new  ArrayList<>();
//		if(initTime!=null) {
//			//��ǰ�¶�
//			  thermometerList= thermometerDao.getThermometers();
//			
//			//��ǰʪ��
//			  hygrometersListnew=hygrometerDao.getHygrometers();
//		}
//		if(dwTime!=null) {
//			//��ǰ�Ŵ���״̬
//			doorsAndWindowsListnew=doorsAndWindowsDao.getDoorsAndWindows();
//		}
//		
//		if(lightTime!=null) {
//			//��ǰ�Ƶ���Ϣ
//			lightsListnew=lightDao.getLight();
//		}
//		
//		//�Ŵ��豸�б�
//		String [] dws= {"004","005"};
//		List<Equipment>  equipmentsList=equipmentDao.getEquipments(dws);
//		
//		//���豸�б�
//		String [] lis= {"001"};
//		List<Equipment>  lisList=equipmentDao.getEquipments(lis);
//		
//		List<Thermometer> thermometersListAll=new ArrayList<Thermometer>();
//		
//			//�¶ȵ������б�
//			thermometersListAll=thermometerDao.getThermometers();
//		List<Hygrometer> hytHygrometersListAll=new ArrayList<Hygrometer>();
//			//ʪ�ȵ������б�
//			hytHygrometersListAll=hygrometerDao.getHygrometers();
//		
//		req.setAttribute("thermometerList", thermometerList);
//		req.setAttribute("hygrometersList", hygrometersListnew);
//		req.setAttribute("doorsAndWindowsList", doorsAndWindowsListnew);
//		req.setAttribute("equipmentsList", equipmentsList);
//		req.setAttribute("thermometersListAll", thermometersListAll);
//		req.setAttribute("hytHygrometersListAll", hytHygrometersListAll);
//		req.setAttribute("lightsList", lightsListnew);
//		req.setAttribute("lisList", lisList);
//		req.getRequestDispatcher("smarthome.jsp").forward(req, resp); 
//		
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

}
