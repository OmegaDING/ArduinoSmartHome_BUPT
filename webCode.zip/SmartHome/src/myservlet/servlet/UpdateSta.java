package myservlet.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.JSON;
import com.sun.corba.se.spi.ior.IdentifiableFactoryFinder;


@WebServlet("/UpdateStaServlet")
public class UpdateSta extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateSta() {
        super();
        // TODO Auto-generated constructor stub
    }

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    response.setHeader("Content-type", "text/html;charset=UTF-8");
	    String fanId=request.getParameter("type");
		String typeName=request.getParameter("status");
		String id=request.getParameter("ID");
		if (fanId.equals("0")) {
			switch (typeName) {
				case "0":
					typeName="0";
					break;
				case "33":
					typeName="1";
					break;
				case "66":
					typeName="2";
					break;
				case "100":
					typeName="3";
					break;
			}
		} else if (fanId.equals("4")) {
			switch (typeName) {
				case "0":
					typeName="0";
					break;
				case "100":
					typeName="1";
					break;
			}
		
		}
		
        Socket socket=new Socket("192.168.43.103",8888);//telecom ip+port
        
        OutputStream out=socket.getOutputStream();
        String con=fanId+typeName+id;
        out.write(con.getBytes());//content��00L0215
        

//        InputStream in=socket.getInputStream();
//        byte[] data=new byte[1024];
//        int len=in.read(data);
//        System.out.println(new String(data,0,len));
//        
        socket.close();
		String str = JSON.toJSONString("success"); 
		PrintWriter out1 = response.getWriter();
		out1.print(str);
		out1.flush();
		out1.close();
	}
	

}
