package myservlet.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;

import myservlet.dao.LightDaoType;
import myservlet.dao.impl.LightDaoimplType;
import vo.LightType;


@WebServlet("/LightTypeServlet")
public class LightTypeServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Content-type", "text/html;charset=UTF-8");
		String typeName=req.getParameter("typeName");
		
		LightDaoType lightDao=new LightDaoimplType();
		List<LightType> light=lightDao.lightSelectTypes(typeName);//���ݿ��ѯ
		 //Ԥ��servlet��Ϊ�Ժ�ʹ��js��׼��
		 String str = JSON.toJSONString(light); 
		 PrintWriter out = resp.getWriter();
		 out.print(str);
	     out.flush();
	     out.close();
		 
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
}

