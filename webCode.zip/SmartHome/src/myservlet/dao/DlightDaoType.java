package myservlet.dao;


import java.util.List;

import vo.DlightType;


public interface DlightDaoType {
	List<DlightType> dlightSelectTypes(String typeName);
}
