package myservlet.dao;

import java.util.List;

import vo.Thermometer;

public interface ThermometerDao {
	
	List<Thermometer> getThermometers();

}
