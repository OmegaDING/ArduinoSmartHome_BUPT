package myservlet.dao;

import java.util.List;

import vo.Fire;


public interface FireDao {
	List<Fire> getFire();
	
}
