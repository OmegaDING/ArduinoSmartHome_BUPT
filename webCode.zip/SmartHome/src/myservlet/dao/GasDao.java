package myservlet.dao;

import java.util.List;

import vo.Gas;


public interface GasDao {
	List<Gas> getGas();
}
