package myservlet.dao;

import java.util.ArrayList;

import vo.Fan;
import vo.Light;



public interface FanDao {
	ArrayList<Fan> getFan(String typeName,String fanId);
	
}
