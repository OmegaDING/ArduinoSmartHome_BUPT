package myservlet.dao;

import java.util.List;

import vo.FanType;

public interface FanDaoType {
	List<FanType> fanSelectTypes(String typeName);
}
