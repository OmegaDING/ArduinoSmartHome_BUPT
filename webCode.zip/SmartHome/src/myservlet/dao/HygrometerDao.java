package myservlet.dao;

import java.util.List;

import vo.Hygrometer;


public interface HygrometerDao {
	List<Hygrometer> getHygrometers();

}
