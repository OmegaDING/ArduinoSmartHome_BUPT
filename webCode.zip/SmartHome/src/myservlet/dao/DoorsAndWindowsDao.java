package myservlet.dao;

import java.util.ArrayList;
import java.util.List;

import vo.DoorsAndWindows;


//ʵ����
public interface DoorsAndWindowsDao {
	List<DoorsAndWindows> getDoorsAndWindows(String typeName,String dwId);
	
}