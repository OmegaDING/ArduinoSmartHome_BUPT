package myservlet.dao;

import java.util.ArrayList;

import vo.Light;


public interface LightDao {
	
	ArrayList<Light> getLight(String typeName,String lightId);
	
}
