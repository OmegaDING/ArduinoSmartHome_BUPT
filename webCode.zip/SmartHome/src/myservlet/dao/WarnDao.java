package myservlet.dao;

import java.util.List;

import vo.Warning;



public interface WarnDao {
	List<Warning> getWarning();

}
