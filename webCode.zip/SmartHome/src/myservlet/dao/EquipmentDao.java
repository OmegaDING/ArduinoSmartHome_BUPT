package myservlet.dao;

import java.util.List;


import vo.Equipment;

public interface EquipmentDao {
	
	List<Equipment> getEquipments(String [] args);
	
	
}
