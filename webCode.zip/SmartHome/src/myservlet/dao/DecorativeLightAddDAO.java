package myservlet.dao;

import vo.Equipment;
import vo.Light;

public interface DecorativeLightAddDAO {
	void getLight(Light light,Equipment E);
}
