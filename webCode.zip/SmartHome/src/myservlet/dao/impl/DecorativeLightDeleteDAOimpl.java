package myservlet.dao.impl;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import db.DBConnect;
import myservlet.dao.LightDao;
import myservlet.servlet.LoginServlet;
import vo.Light;
import vo.Equipment;


public class DecorativeLightDeleteDAOimpl {
	 	
	public void getLight(Light light,Equipment E){
		
		try {
		//	String sql = "select * from light l,equipment e ";
			//String sql = " Delete From light WHERE lightID=? AND lightState=100";
			String sql = " update equipment set status='1' WHERE eID=? ";
			String sql1= "insert into light values(?,?,?)";
		//	update equipment  set status='1' where eID=(select e.eID from equipment e,light l where)
			//String sql1= " Delete From Equipment WHERE eID=?";
			PreparedStatement pstmt = null ;
			PreparedStatement pstmt1 = null ;//准备sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
		    pstmt1 = dbc.getConnection().prepareStatement(sql1) ; 
		    
		    pstmt1.setString(1,light.getLightID()) ; 
			   pstmt1.setLong(2,0) ; 
			   
			   long now=System.currentTimeMillis();//获取当前系统时间
	           Date d=new Date(now);
	           SimpleDateFormat sdf = new SimpleDateFormat( " yyyy-MM-dd HH:mm:ss " );//设置格式yyyy-MM-dd HH:mm:ss
	           String str = sdf.format(d);//注意此时是string类型
	           java.util.Date d1=null;
	           d1 = sdf.parse(str);//将string类型转化为sql.util.Date的时�?
	           java.sql.Timestamp ts= new java.sql.Timestamp(d1.getTime());//很关键的�?步，没有这个时分秒就不见�?
	           
	         
	           pstmt1.setTimestamp(3, ts);//这是为sql语句设置参数，注意用的是setTimestamp（）
		 
		    
		    pstmt.setString(1,E.geteID()) ; 
		   
		    //pstmt1.setString(1,E.geteID()) ; 
		   
		      
		    
		    int rs = pstmt.executeUpdate();	
		    int rs1 = pstmt1.executeUpdate();	
		   
	
			
			pstmt.close();
			pstmt1.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		
	}
	
	
}


