package myservlet.dao.impl;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import db.DBConnect;
import myservlet.servlet.LoginServlet;
import java.util.List;
import myservlet.dao.ThermometerDao;
import vo.Thermometer;

public class ThermometerDaoImpl implements ThermometerDao {

	@Override
	public List<Thermometer> getThermometers() {
		List<Thermometer> thermometers=new ArrayList<Thermometer>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			
			dbc = new DBConnect();
			String sql="SELECT * FROM thermometer order by temUpdateTime desc limit 6 ";

			pstmt=dbc.getConnection().prepareStatement(sql);
			ResultSet resultSet=pstmt.executeQuery();
			while (resultSet.next()) {
				Thermometer thermometer=new Thermometer();
			
				thermometer.setTemValue(resultSet.getFloat("temValue"));
				thermometer.setTemUpdateTime(resultSet.getString("temUpdateTime"));
				thermometers.add(thermometer);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return thermometers;
	}

}
