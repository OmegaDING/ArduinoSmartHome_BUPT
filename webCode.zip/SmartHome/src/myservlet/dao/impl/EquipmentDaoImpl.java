package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.EquipmentDao;
import vo.Equipment;
import vo.Hygrometer;

public class EquipmentDaoImpl implements EquipmentDao{
	@Override
	public List<Equipment> getEquipments(String [] args) {
		List<Equipment> equipments=new ArrayList<Equipment>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			
			
			String sql="SELECT * FROM smarthome.equipment where 1=1 and equipment.status=0";
			for (int i = 0; i < args.length; i++) {
				if(i!=0) {
					sql+=" or ";
				}
				if(i==0) {
					sql+=" and ";
				}
				sql+=" cID='"+args[i]+"'";
			}
			pstmt=dbc.getConnection().prepareStatement(sql);
			ResultSet resultSet=pstmt.executeQuery();
			while (resultSet.next()) {
				Equipment equipment=new Equipment();
				equipment.seteID(resultSet.getString("eID"));
				equipment.seteName(resultSet.getString("eName"));
				equipments.add(equipment);
			}
			resultSet.close();
			pstmt.close();
			
		}catch (Exception e) {
			
		}finally {
			dbc.close();
		}
		
		return equipments;
	}

}
