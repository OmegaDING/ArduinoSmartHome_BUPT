package myservlet.dao.impl;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import db.DBConnect;
import myservlet.dao.LightDao;
import myservlet.servlet.LoginServlet;
import vo.Light;


public class LightDAOImpl implements LightDao{
	 	
	public ArrayList<Light> getLight(String typeName,String lightId){
		ArrayList<Light> lightlist=new ArrayList<Light>();
		try {
			
			String sql="select l.*,e.eName from light l,equipment e ,category c where   l.lightID=e.eID  and c.cID=e.cID  and c.cName='"+typeName+"'  and l.lightID='"+lightId+"'  and e.status=0 order by l.lightUpdateTime desc limit 6";
			//if(lightUpdateTime!=null&&!lightUpdateTime.equals("")){
				
			//			sql+=" and lightUpdateTime='"+lightUpdateTime+"' and e.fId=?;";
			//}
			PreparedStatement pstmt = null ;  //准备sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
 
		    ResultSet rs = pstmt.executeQuery();			
			while (rs.next()) {
				Light light=new Light(rs.getString("lightID"),rs.getInt("lightState"),rs.getString("lightUpdateTime"));
				lightlist.add(light);
			}
			rs.close();
			pstmt.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		return lightlist;
	}
	

}


