package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.CategorySelectDao;
import vo.Category;
import vo.ManufacturerBean;

public class CategorySelectDaoImpl implements CategorySelectDao {

	@Override
	public Category getCategories(String typeName) {
		Category category=new Category();
		try {
			
			String sql="SELECT * FROM category where cName='"+typeName+"'";
		 
			PreparedStatement pstmt = null ;  //准备sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
 
		    ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				category.setCgID(rs.getString("cID"));
				category.setCgName(rs.getString("cName"));
				 
			}
			rs.close();
			pstmt.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		return category;
	}

}
