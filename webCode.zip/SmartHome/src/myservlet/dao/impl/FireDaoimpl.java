package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.FireDao;
import vo.Fire;


public class FireDaoimpl implements FireDao {

	@Override
	public List<Fire> getFire(){
		List<Fire> firelist=new ArrayList<Fire>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="SELECT * FROM smarthome.fire order by fireUpdateTime desc limit 1";
			pstmt=dbc.getConnection().prepareStatement(sql);
			ResultSet resultSet=pstmt.executeQuery();
			Fire fire=null;
			while (resultSet.next()) {
				fire=new Fire();
				fire.setFireID(resultSet.getString("fireID"));
				fire.setFireState(resultSet.getInt("fireState"));
				fire.setFireUpdateTime(resultSet.getString("fireUpdateTime"));
				firelist.add(fire);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return firelist;
	}
}