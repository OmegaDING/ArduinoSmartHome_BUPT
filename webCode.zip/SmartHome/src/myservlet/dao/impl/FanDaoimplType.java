package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.FanDaoType;
import vo.FanType;


public class FanDaoimplType implements FanDaoType {

	@Override
	public List<FanType> fanSelectTypes(String typeName) {
		List<FanType> fanlist=new ArrayList<FanType>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="select e.eName,e.eID from equipment e,category c where e.cID=c.cID  and c.cName=? and e.status=0 order by e.eID ";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, typeName);			
			ResultSet resultSet=pstmt.executeQuery();
			FanType fan=null;
			while (resultSet.next()) {
				fan=new FanType();
				fan.setTypeId(resultSet.getString("eID"));
				fan.setTypeName(resultSet.getString("eName"));
	 
				fanlist.add(fan);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return fanlist;
	}

}

