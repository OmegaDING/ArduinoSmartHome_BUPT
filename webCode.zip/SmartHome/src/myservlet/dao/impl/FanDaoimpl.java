package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import db.DBConnect;
import myservlet.dao.FanDao;
import myservlet.servlet.LoginServlet;
import vo.Fan;


public class FanDaoimpl implements FanDao{
	 
	public ArrayList<Fan> getFan(String typeName,String fanId){
		ArrayList<Fan> fanlist=new ArrayList<Fan>();
		try {
			String sql = "select f.*,e.eName from fan f,equipment e ,category c where   f.fanID=e.eID  and c.cID=e.cID  and c.cName='"+typeName+"'  and f.fanID='"+fanId+"' and e.status=0  order by f.fanUpdateTime desc limit 6";
			
			PreparedStatement pstmt = null ; 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
	
		    ResultSet rs = pstmt.executeQuery();			
			while (rs.next()) {
				Fan fan=new Fan();
				fan.setFanID(rs.getString("fanID"));
				fan.setFanState(rs.getInt("fanState"));
				fan.setFanUpdateTime(rs.getString("fanUpdateTime"));
				fanlist.add(fan);
			}
			rs.close();
			pstmt.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		return fanlist;
	}
	

}
