package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import db.DBConnect;
import myservlet.dao.WarnDao;
import vo.Warning;
 
public class WarnDaoimpl implements WarnDao {
	
	@Override
	public List<Warning> getWarning(){
		List<Warning> warninglist=new ArrayList<Warning>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="SELECT * FROM smarthome.warning  order by warnUpdateTime desc limit 1";
			pstmt=dbc.getConnection().prepareStatement(sql);
			ResultSet resultSet=pstmt.executeQuery();
			Warning warning=null;
			while (resultSet.next()) {
				warning=new Warning();
				warning.setWarnID(resultSet.getString("warnID"));
				warning.setWarnState(resultSet.getInt("warnState"));
				warning.setWarnUpdateTime(resultSet.getString("warnUpdateTime"));
				warninglist.add(warning);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return warninglist;
	}
}
