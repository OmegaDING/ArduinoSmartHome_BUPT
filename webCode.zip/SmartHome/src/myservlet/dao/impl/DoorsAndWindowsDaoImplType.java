package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.DoorsAndWindowsDaoType;
import vo.DoorsAndWindows;
import vo.DoorsAndWindowsType;

public class DoorsAndWindowsDaoImplType implements DoorsAndWindowsDaoType {

	@Override
	public List<DoorsAndWindowsType> doorsAndWindowsSelectTypes(String typeName) {
		List<DoorsAndWindowsType> doorsandwindowslist=new ArrayList<DoorsAndWindowsType>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="select e.eName,e.eID from equipment e,category c where e.cID=c.cID  and c.cName=? and e.status=0 order by e.eID ";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, typeName);			
			ResultSet resultSet=pstmt.executeQuery();
			DoorsAndWindowsType doorsandwindows=null;
			while (resultSet.next()) {
				doorsandwindows=new DoorsAndWindowsType();
				doorsandwindows.setTypeId(resultSet.getString("eID"));
				doorsandwindows.setTypeName(resultSet.getString("eName"));
	 
				doorsandwindowslist.add(doorsandwindows);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return doorsandwindowslist;
	}

}
