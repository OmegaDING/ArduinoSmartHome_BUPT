package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import db.DBConnect;
import myservlet.dao.DoorsAndWindowsDao;
import vo.DoorsAndWindows;

public class DoorsAndWindowsDaoimpl implements DoorsAndWindowsDao {

	@Override
	public List<DoorsAndWindows> getDoorsAndWindows(String typeName,String dwId){
		List<DoorsAndWindows> doorsandwindowslist=new ArrayList<DoorsAndWindows>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="select d.*,e.eName from doorsandwindows d,equipment e ,category c where   d.dwID=e.eID  and c.cID=e.cID  and c.cName='"+typeName+"'  and d.dwID='"+dwId+"' and e.status=0 order by d.dwUpdateTime desc limit 6";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
		 
			ResultSet resultSet=pstmt.executeQuery();
			DoorsAndWindows doorsandwindows=null;
			while (resultSet.next()) {
				doorsandwindows=new DoorsAndWindows();
				doorsandwindows.setDwID(resultSet.getString("dwID"));
				doorsandwindows.setDwState(resultSet.getInt("dwState"));
				doorsandwindows.setDwUpdateTime(resultSet.getString("dwUpdateTime"));
				doorsandwindows.setDwName(resultSet.getString("eName"));
				doorsandwindowslist.add(doorsandwindows);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return doorsandwindowslist;
	}


}
