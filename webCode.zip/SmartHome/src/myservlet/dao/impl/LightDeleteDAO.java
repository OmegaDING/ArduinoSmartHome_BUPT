package myservlet.dao.impl;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import db.DBConnect;
import myservlet.dao.LightDao;
import myservlet.servlet.LoginServlet;
import vo.Light;
import vo.Equipment;


public class LightDeleteDAO {
	 	
	public void getLight(Light light,Equipment E){
		
		try {
		//	String sql = "select * from light l,equipment e ";
			String sql = " update equipment set status='1'WHERE eID=?";
			//String sql = " Delete From light WHERE lightID=? AND lightState!=100";
//			String sql1= "insert into light values(?,?,?)";
			PreparedStatement pstmt = null ;
			PreparedStatement pstmt1 = null ;//鍑嗗sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
//		    pstmt1 = dbc.getConnection().prepareStatement(sql1) ; 
//		    
		 
//		   
//		   pstmt1.setString(1,light.getLightID()) ; 
//		   pstmt1.setLong(2,0) ; 
		   
		   long now=System.currentTimeMillis();//鑾峰彇褰撳墠绯荤粺鏃堕棿
           Date d=new Date(now);
           SimpleDateFormat sdf = new SimpleDateFormat( " yyyy-MM-dd HH:mm:ss " );//璁剧疆鏍煎紡yyyy-MM-dd HH:mm:ss
           String str = sdf.format(d);//娉ㄦ剰姝ゆ椂鏄痵tring绫诲瀷
           java.util.Date d1=null;
           d1 = sdf.parse(str);//灏唖tring绫诲瀷杞寲涓簊ql.util.Date鐨勬椂闂�
           java.sql.Timestamp ts= new java.sql.Timestamp(d1.getTime());//寰堝叧閿殑涓�姝ワ紝娌℃湁杩欎釜鏃跺垎绉掑氨涓嶈浜�
           
         
//           pstmt1.setTimestamp(3, ts);//杩欐槸涓簊ql璇彞璁剧疆鍙傛暟锛屾敞鎰忕敤鐨勬槸setTimestamp锛堬級
		    
		   
		    pstmt.setString(1,E.geteID()) ; 
		   
		      
		    
		    int rs = pstmt.executeUpdate();	
//		    int rs1 = pstmt1.executeUpdate();	
//		   
	
			//rs.close();
			pstmt.close();
		//	pstmt1.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		
	}
	
	
}


