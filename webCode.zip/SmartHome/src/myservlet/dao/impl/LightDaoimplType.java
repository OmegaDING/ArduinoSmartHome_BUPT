package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.LightDaoType;
import vo.LightType;


public class LightDaoimplType implements LightDaoType {

	@Override
	public List<LightType> lightSelectTypes(String typeName) {
		List<LightType> lightlist=new ArrayList<LightType>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="select e.eName,e.eID from equipment e,category c where e.cID=c.cID  and c.cName=? and e.status=0 order by e.eID ";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, typeName);			
			ResultSet resultSet=pstmt.executeQuery();
			LightType light=null;
			while (resultSet.next()) {
				light=new LightType();
				light.setTypeId(resultSet.getString("eID"));
				light.setTypeName(resultSet.getString("eName"));
	 
				lightlist.add(light);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return lightlist;
	}

}
