package myservlet.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.HygrometerDao;
import vo.Hygrometer;
import vo.Thermometer;

public class HygrometerDaoimpl implements HygrometerDao{
	@Override
	public List<Hygrometer> getHygrometers() {
		List<Hygrometer> hygrometers=new ArrayList<Hygrometer>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="SELECT * FROM smarthome.hygrometer order by humUpdateTime desc limit 6";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
			ResultSet resultSet=pstmt.executeQuery();
			while (resultSet.next()) {
				Hygrometer hygrometer=new Hygrometer();
				hygrometer.setHumUpdateTime(resultSet.getString("humUpdateTime"));
//				hygrometer.setHygId(resultSet.getString("hygId"));
				hygrometer.setHumValue(resultSet.getFloat("humValue"));
				hygrometers.add(hygrometer);
			}
			resultSet.close();
			pstmt.close();
			
		}catch (Exception e) {
			
		}finally {
			dbc.close();
		}
		
		return hygrometers;
	}

}
