package myservlet.dao.impl;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

import db.DBConnect;
import myservlet.servlet.LoginServlet;
import vo.DoorsAndWindows;
import vo.Equipment;


public class DoorsAndWindowsAddDAO {
	 	
	public void getdw(DoorsAndWindows dw,Equipment E){
		
		try {
		//	String sql = "select * from light l,equipment e ";
			String sql = "insert into equipment values(?,?,?,?,?,?,?) ";
			String sql1= "insert into doorsandwindows values(?,?,?)";
			PreparedStatement pstmt = null ;
			PreparedStatement pstmt1 = null ;//准备sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
		    pstmt1 = dbc.getConnection().prepareStatement(sql1) ; 
		    
		    long now=System.currentTimeMillis();//获取当前系统时间
            Date d=new Date(now);
            SimpleDateFormat sdf = new SimpleDateFormat( " yyyy-MM-dd HH:mm:ss " );//设置格式yyyy-MM-dd HH:mm:ss
            String str = sdf.format(d);//注意此时是string类型
            java.util.Date d1=null;
            d1 = sdf.parse(str);//将string类型转化为sql.util.Date的时间
            java.sql.Timestamp ts= new java.sql.Timestamp(d1.getTime());//很关键的一步，没有这个时分秒就不见了
		    
		    pstmt1.setString(1,dw.getDwID()) ; 
		    pstmt1.setInt(2,dw.getDwState()) ;
		    pstmt1.setTimestamp(3, ts);
		   
		    pstmt.setString(1,E.geteID()) ; 
		    pstmt.setString(2,E.geteName()) ;
		    pstmt.setString(3,E.getDescription()) ; 
		    pstmt.setInt(4,E.getStatus()) ; 
		    pstmt.setString(5,E.getcID()) ;
		    pstmt.setString(6,E.getmID()) ;
		    pstmt.setString(7, LoginServlet.familyid);
		      
		    
		    int rs = pstmt.executeUpdate();	
		    int rs1 = pstmt1.executeUpdate();	
		   
	
			//rs.close();
			pstmt.close();
			pstmt1.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		
	}
	
	
}


