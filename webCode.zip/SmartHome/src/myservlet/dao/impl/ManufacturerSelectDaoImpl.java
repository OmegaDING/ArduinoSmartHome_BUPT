package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import db.DBConnect;
import myservlet.dao.ManufacturerSelectDao;
import vo.ManufacturerBean;

public class ManufacturerSelectDaoImpl implements ManufacturerSelectDao {

	@Override
	public List<ManufacturerBean> getManufacturers() {
		List<ManufacturerBean> mList=new ArrayList<ManufacturerBean>();
		try {
			
			String sql="SELECT * FROM manufacturer";
		 
			PreparedStatement pstmt = null ;  //准备sql 
		    DBConnect dbc = new DBConnect();  
		    pstmt = dbc.getConnection().prepareStatement(sql) ; 
 
		    ResultSet rs = pstmt.executeQuery();
		    ManufacturerBean manufacturer=null;
			while (rs.next()) {
				manufacturer=new ManufacturerBean();
				manufacturer.setMfID(rs.getString("mID"));
				manufacturer.setMfName(rs.getString("mName"));
				mList.add(manufacturer);
			}
			rs.close();
			pstmt.close();
			dbc.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());   
		}
		
		return mList;
	 
	}

}
