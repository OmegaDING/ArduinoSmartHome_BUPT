/**
 * 
 */
package myservlet.dao.impl;

/**
 * @author å�Žä¸º
 *
 */
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import db.DBConnect;
import myservlet.servlet.LoginServlet;
import vo.User;
import vo.DoorsAndWindows;
import vo.Fan;
import vo.Light;

public class FanRowSelectedDao {

	
	public ArrayList<Fan> query(int i) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<Fan> lstpost=new ArrayList<Fan>();
		int flag = 0;
	
		String sql="select distinct(e.eID) from fan fn,equipment e,user_has_family uf,family f where e.eID=fn.fanID and f.fID=uf.Family_fID and uf.Family_fID=e.fID and e.status='0'and e.eName like \"%fan%\" and f.fID=?; ";
        PreparedStatement pstmt = null ;   
        DBConnect dbc = null;   
        


     
        try{   
            // ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½Ý¿ï¿½   
            dbc = new DBConnect() ;   
            pstmt = dbc.getConnection().prepareStatement(sql) ; 
   
          
            pstmt.setString(1,LoginServlet.familyid);
       
           
        
            ResultSet rs = pstmt.executeQuery();
        
            System.out.println(111);
           while(rs.next()){  
        	   
        	   Fan fan=new Fan();
        	
        	    fan.setFanID(rs.getString("eID"));
        	    
				lstpost.add(fan);
        	   
  
        	  
                	flag = 1;
              
            }   
         
            rs.close() ; 
           pstmt.close() ;   
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{   
           
            dbc.close() ;   
        }   
		return lstpost;
	}

	/**
	 * @param i
	 * @return
	 */


	

}