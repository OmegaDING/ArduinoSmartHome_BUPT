package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.DoorsAndWindowsDao;
import myservlet.dao.GasDao;
import vo.DoorsAndWindows;
import vo.Gas;


public class GasDaoimpl implements GasDao {

		@Override
		public List<Gas> getGas(){
			List<Gas> gaslist=new ArrayList<Gas>();
			PreparedStatement pstmt = null;
			DBConnect dbc = null;
			try {
				dbc = new DBConnect();
				String sql="SELECT * FROM smarthome.gas order by gasUpdateTime desc limit 1";
				
				pstmt=dbc.getConnection().prepareStatement(sql);
				ResultSet resultSet=pstmt.executeQuery();
				Gas gas=null;
				while (resultSet.next()) {
					gas=new Gas();
					gas.setGasID(resultSet.getString("gasID"));
					gas.setGasState(resultSet.getInt("gasState"));
					gas.setGasUpdateTime(resultSet.getString("gasUpdateTime"));
					gaslist.add(gas);
				}
				resultSet.close();
				pstmt.close();
				
			} catch (Exception e) {
				// TODO: handle exception
			}finally {
				dbc.close();
			}
			
			return gaslist;
		}
}


