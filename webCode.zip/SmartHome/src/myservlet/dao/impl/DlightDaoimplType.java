package myservlet.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import myservlet.dao.DlightDaoType;
import vo.DlightType;


public class DlightDaoimplType implements DlightDaoType {

	@Override
	public List<DlightType> dlightSelectTypes(String typeName) {
		List<DlightType> dlightlist=new ArrayList<DlightType>();
		PreparedStatement pstmt = null;
		DBConnect dbc = null;
		try {
			dbc = new DBConnect();
			String sql="select e.eName,e.eID from equipment e,category c where e.cID=c.cID  and c.cName=? and e.status=0 order by e.eID ";
			
			pstmt=dbc.getConnection().prepareStatement(sql);
			pstmt.setString(1, typeName);			
			ResultSet resultSet=pstmt.executeQuery();
			DlightType dlight=null;
			while (resultSet.next()) {
				dlight=new DlightType();
				dlight.setTypeId(resultSet.getString("eID"));
				dlight.setTypeName(resultSet.getString("eName"));
	 
				dlightlist.add(dlight);
			}
			resultSet.close();
			pstmt.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbc.close();
		}
		
		return dlightlist;
	}

}

