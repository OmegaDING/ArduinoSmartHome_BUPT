package myservlet.dao.impl;

import java.sql.PreparedStatement;


import java.sql.ResultSet;
import java.sql.SQLException;

import com.sun.org.apache.regexp.internal.recompile;

import db.DBConnect;
import myservlet.dao.UserDao;
import util.MD5Utils;
import vo.Family;
import vo.User;


public class UserDAOImpl implements UserDao {

	/**
     * queryByUsername(User user) 查询功能
     * @return flag返回查询成功或失败
  
     */
	public String queryByUsername(User user,Family f) throws Exception {
		// TODO Auto-generated method stub
		int flag = 0;
		String userId="0";
	//	String sql = "select * from user where userName=?";//问号相当于占位符
		String sql = " select u.userID,userName,userPassword,f.fID from user u,family f,user_has_family uf where f.fID=uf.Family_fID and u.userID=uf.User_userID and u.username=?";
        PreparedStatement pstmt = null ;  //准备sql 
        DBConnect dbc = null;  
        
        
        try{                 
            dbc = new DBConnect() ;  
            //准备sql
            pstmt = dbc.getConnection().prepareStatement(sql) ;  //获取连接对象 
            pstmt.setString(1,user.getUserName()) ;   //绑定参数           
            ResultSet rs = pstmt.executeQuery();//执行语句 结果集
      
            while(rs.next()){                
            	
                if(rs.getString("userPassword").equals(MD5Utils.stringToMD5(user.getUserPassword()))){
                	flag = 1;
                	userId=rs.getString("userID");
                	f.setfID(rs.getString("fID"));
                }
                
                
            }   
            rs.close() ; //结果集关闭
            pstmt.close() ;   
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{               
            dbc.close() ;   
        }   
//		return flag;
		return userId;
	}
	
	
	/**
     * Insert(User user) 添加功能
     * @return flag返回添加成功或失败
  
     */
	public int Insert(User user,Family f) throws Exception {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "insert into user values(?,?,?,?,?,?)";//问号相当于占位符
		String sql1 = "insert into family values(?,?,?,?)";//问号相当于占位符
		String sql2 = "insert into user_has_family values(?,?)";//问号相当于占位符
		
        PreparedStatement pstmt = null ;  //准备sql
        PreparedStatement pstmt1 = null ;
        PreparedStatement pstmt2 = null ;
        DBConnect dbc = null;  
    
        
        try{   
              
            dbc = new DBConnect() ;                       
            pstmt = dbc.getConnection().prepareStatement(sql) ;  //获取连接对象 
            pstmt1 = dbc.getConnection().prepareStatement(sql1) ; 
            pstmt2 = dbc.getConnection().prepareStatement(sql2) ; 
            //绑定参数
            pstmt.setString(1,user.getUserID()) ;   
            pstmt.setString(2, MD5Utils.stringToMD5(user.getUserPassword())) ;
            pstmt.setString(3,user.getUserName()) ;
            pstmt.setString(4,user.getUserPhone()) ;
            pstmt.setString(5,user.getUserGender()) ;
            pstmt.setLong(6,user.getStatus()) ;  
            
            pstmt1.setString(1,f.getfID()) ;   
            pstmt1.setString(2,f.getfName()) ;
            pstmt1.setString(3,f.getAddress()) ;
            pstmt1.setInt(4,f.getStatus()) ;
            
            pstmt2.setString(1,user.getUserID()) ;
            pstmt2.setString(2,f.getfID()) ;   
            
            int  rs = pstmt.executeUpdate();//执行语句 结果集  
            int  rs1 = pstmt1.executeUpdate();//执行语句 结果集  
            int  rs2 = pstmt2.executeUpdate();//执行语句 结果集  
            if(rs>0&&rs1>0&&rs2>0){         
              flag=1;           
            }  
            pstmt.close() ;   
        }catch (SQLException e){   
            System.out.println(e.getMessage());   
        }finally{                
            dbc.close() ;   
        }          
		return flag;
	}	
	
	
	public int changePassword(User user) throws Exception{
		 int flag = 0;
		 
		 String sql = "update user set userpassword=? where username=?";
		 PreparedStatement pstmt = null ; 
	     DBConnect dbc = null;  	  	        
	        try{                 
	            dbc = new DBConnect() ;  
	            //准备sql
	            pstmt = dbc.getConnection().prepareStatement(sql) ; 
	            //获取连接对象 
	           
	            pstmt.setString(1, MD5Utils.stringToMD5(user.getUserPassword())) ; 
	            pstmt.setString(2,user.getUserName()) ;           
	            int rs = pstmt.executeUpdate();//执行语句 结果集
	            //int  rs1 = pstmt.executeUpdate();//执行语句 结果集
	           // flag=1;
	            if(rs>0){         
	                flag=1;           
	              } 
	           // while(rs.next()){                
	                //if(rs.getString("userName").equals(user.getUserName())){
	               // 	flag = 1;
	                	
	                
	                
	          //  }   
	           // rs.close() ; //结果集关闭
	            pstmt.close() ;   
	        }catch (SQLException e){   
	            System.out.println(e.getMessage());   
	        }finally{               
	            dbc.close() ;   
	        }   
			return flag;
		
		
		
	}
	
	
}