package myservlet.dao;

import java.util.List;

import vo.ManufacturerBean;

public interface ManufacturerSelectDao {
	
	List<ManufacturerBean> getManufacturers();

}
