package myservlet.dao;

import vo.Family;
import vo.User;

public interface UserDao {	
	public String queryByUsername(User user,Family f) throws Exception;
	public int Insert(User user,Family f) throws Exception;
	public int changePassword(User user) throws Exception;
	
}
