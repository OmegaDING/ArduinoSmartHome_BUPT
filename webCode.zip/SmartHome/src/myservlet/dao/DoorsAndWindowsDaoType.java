package myservlet.dao;

import java.util.List;

import vo.DoorsAndWindowsType;

public interface DoorsAndWindowsDaoType {
	List<DoorsAndWindowsType> doorsAndWindowsSelectTypes(String typeName);
  
}
