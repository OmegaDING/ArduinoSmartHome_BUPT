package myservlet.dao;

import java.util.List;

import vo.Category;
import vo.ManufacturerBean;

public interface CategorySelectDao {
	
	Category getCategories(String typeName);

}
