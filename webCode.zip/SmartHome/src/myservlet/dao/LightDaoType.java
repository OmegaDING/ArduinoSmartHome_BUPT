package myservlet.dao;

import java.util.List;

import vo.FanType;
import vo.LightType;



public interface LightDaoType {
	List<LightType> lightSelectTypes(String typeName);
}
