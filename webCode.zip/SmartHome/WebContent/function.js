function change(img){
	img.src="CodeServlet?"+Math.random();
}